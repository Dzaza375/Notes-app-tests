NotesApp sample project
-----------------------
Contains Java source files and basic resources for a simple Notes application.
- Package: com.example.notesapp
- Storage: SharedPrefStorage (JSON in SharedPreferences)
- Activities: MainActivity, AddNoteActivity, DeleteNoteActivity

You can import this directory into Android Studio as an existing project (you will need to create a proper Gradle wrapper and module files).
